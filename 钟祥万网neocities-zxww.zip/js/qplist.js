

window.QPlayer.list = [

{ 
"name":"平凡的一天",
"artist":"毛不易",
"audio":"https://music.163.com/song/media/outer/url?id=569214247.mp3",
"cover":"https://p2.music.126.net/vmCcDvD1H04e9gm97xsCqg==/109951163350929740.jpg?param=106x106"
},


{
"name":"写给黄淮（cover：解忧邵帅）",
"artist":"西彬",
"audio":"https://music.163.com/song/media/outer/url?id=1343506065.mp3",
"cover":"https://p2.music.126.net/NeZEUwXVyNyoqacFSGWsdQ==/109951163832648101.jpg?param=106x106"
},

 {
"name":"突然之间",
"artist":"G.E.M.邓紫棋",
"audio":"https://music.163.com/song/media/outer/url?id=1323301365.mp3",
"cover":"https://p2.music.126.net/X7f92tSJ-b0_sC1u9tgAyQ==/109951163654227442.jpg?param=106x106"
},



{
"name":"孤单心事",
"artist":"颜人中",
"audio":"https://music.163.com/song/media/outer/url?id=1361988914.mp3",
"cover":"https://p2.music.126.net/0KCMOKHHbimwfdVvPPBpTA==/109951164034526943.jpg?param=106x106"
},
             
    {
        "name": "囍（Chinese Wedding）",
        "artist": "葛东琪",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1303289043&auth=377159ae90aa99649566929ef81d193d42cd9f48",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163472855051&auth=99784164a36cabeda6c2308907dfe4fedc22a4bc",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1303289043&auth=3a0e1b84c8ef4732f8a6c18f6264bb9acabd5971"
    },
    
    
   
    {
        "name": "热爱105°C的你",
        "artist": "阿肆",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1840459406&auth=2525b9a13b86cf3471d02e5ccd10846cf7cea6b7",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166098679116&auth=db4e17c2972422d2ec63dad7b85928c23c75e1f2",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1840459406&auth=1131f732c6f89416846ce9444229a13ec2b334fb"
    },
    {
        "name": "红梅赞",
        "artist": "肖战",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1439975538&auth=b67fee8a7a89f820c9ef93af2935b387748b0021",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164898369103&auth=c0abc35f80ca42ab3ab59b055ef1cb0cdb5a1663",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1439975538&auth=e40e5f9bd9cd66bcfea51ff8fd325369ba165300"
    },
    {
        "name": "所 以 愛 會 消 失 對 不 對",
        "artist": "东东",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1475571759&auth=c01def6e2a2334aeabe53fd8a040c7cfd9d9b9ff",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165287187906&auth=917120f000b5912e0772b17468da45f4a696b175",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1475571759&auth=8c25e21933816548117b6bacd4160415686b778e"
    },
    {
        "name": "好想爱这个世界啊 (Live)",
        "artist": "华晨宇",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1436910205&auth=d06806cf5c12484b3adec0f520d1caf15560727c",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164863688864&auth=62012e61f15ec4605ee107c4a5fa5be25ec048a8",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1436910205&auth=be0f34016247f43383b33e3a3058f6b0eebe2265"
    },
    {
        "name": "我的名字",
        "artist": "焦迈奇",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=554241732&auth=f8f5c4f38a3b4587c60ecbe23257c552e9854af4",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164019567772&auth=4099ef509120dfdf325bccc855c515c8e6d05754",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=554241732&auth=0490f05e340d0f9301927143b4a36277116971e0"
    },
    {
        "name": "说散就散",
        "artist": "袁娅维",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=523251118&auth=23603693bd6932396b698101808bbccfd48afee3",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163169027515&auth=152e238ea7048537f26002f17769429ebdc3122e",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=523251118&auth=ee9a1c3375b937f1cdf2d69b43172c43e2eef786"
    },
    {
        "name": "大雾",
        "artist": "未知音素 / 张一乔",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1805088448&auth=875877dd15ecd53fa8e426331b093b52544b08b5",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165547470592&auth=2719b83278646830ead0185618ae98bd392ecc7b",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1805088448&auth=74d77dfc26648b00b08ddc0100b67fa11417031c"
    },
    {
        "name": "等你归来",
        "artist": "程响",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1812673579&auth=4f38fdcf6260a6af7b61ce6c507b86779eea78b4",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165674729204&auth=4c6c1dc8bfdf9306db89d7a072a05903c1ea01e1",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1812673579&auth=6650e021c2b5346202f9b5ffdf270d1f90b5d7c9"
    },
    {
        "name": "白月光与朱砂痣",
        "artist": "水源小樱",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1811147916&auth=2aaf856548f9205b178938ef5d0dc2253c80ba58",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165623595294&auth=5c526e296d15e19c880aef263ebef37d34a45553",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1811147916&auth=1912b4180bd17746869a924c199e287a06c642d0"
    },
    {
        "name": "错位时空",
        "artist": "艾辰",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1808492017&auth=a8bc2f1286cc4592c91bcdde0f8e97bd0a69a794",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165595770076&auth=e91478e342c997fd8d8e1781420a9930ed950402",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1808492017&auth=f7e84e8653fdfd5075deca5cc48c26c80573862e"
    },
    {
        "name": "踏山河",
        "artist": "七叔-叶泽浩",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1804320463&auth=81de1e0f3a5d952b526023abb6dfc788d8f755e7",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165621355537&auth=3551867083ce3f2aa6688a72ecce81eba5e3bc8f",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1804320463&auth=85ff75213690fb7eae30b995dd8bb2447d44719e"
    },
    {
        "name": "星辰大海",
        "artist": "黄霄雲",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1811921555&auth=2d0ca8ea5cb0f8756f39f1e5bc8f4888e636e0f8",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165641911293&auth=947ee817c662b36d30ca19d8e462776d7af9edc5",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1811921555&auth=b006cfcb2c04169e5a9c51f6f4db86ab59fc7a23"
    },
    {
        "name": "一花一剑",
        "artist": "李鑫一",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1492639473&auth=f054b50c10a14942c56730bf04ac19f7282fb0e4",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165393659895&auth=b4611c3d3e8cb944e3c4992aa52cccbeeec64858",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1492639473&auth=6f8c578b372bdafb4ddf9562cda29ddfb33decba"
    },
    {
        "name": "不散",
        "artist": "黄龄",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1490104281&auth=098b11536ca6f08e6d63b46a4a32d93db7d3d602",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165393659895&auth=b4611c3d3e8cb944e3c4992aa52cccbeeec64858",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1490104281&auth=11f3b1bb6d7d40c695a3963b42132d26e46d4497"
    },
    {
        "name": "无别",
        "artist": "张信哲",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1487546210&auth=6ee0bf26eb68cccc5961bf006dffce797d8dc7c6",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165393659895&auth=b4611c3d3e8cb944e3c4992aa52cccbeeec64858",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1487546210&auth=edcc84954511e6bcc4fe4a9833a7043a5e0a7e08"
    },
    {
        "name": "游京",
        "artist": "海伦",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1368398851&auth=957a9b0e0699d3df89611e170f5e567192690a3e",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165545680822&auth=a0dfd63a390ce6a445ed3ef835254972ff21c2bf",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1368398851&auth=34905ff9d3dceb546de1533a71e2f5bff5d6a314"
    },
    {
        "name": "会不会（吉他版）",
        "artist": "刘大壮",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1481164987&auth=832e87cc61e238858d2eaab5ffb7efb5add1750e",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165335411992&auth=50313e279169a68dfe9564b7089e93d1a6ec08f5",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1481164987&auth=b4163da971b621b3c3b5d200ade71a0c747934fe"
    },
    {
        "name": "是想你的声音啊",
        "artist": "傲七爷",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1459950258&auth=0629bb21d9b1f46c6e34f837e79641e183754795",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165109878587&auth=cf9806a88fde08b3d8adb37318e7f3fa70ca0557",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1459950258&auth=ea07434e845c1d386b33e4e1265caa73289e9ae0"
    },
    {
        "name": "他只是经过",
        "artist": "h3R3 / 高旭",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1443838552&auth=61cc190f4f942df391fa35302c76426100a034cd",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165348116023&auth=4df8ae2b733f963dc7cb92871fdadb486cf51576",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1443838552&auth=b3e5f1435ba0fa3fafc21bfda58f8f925ec50737"
    },
    {
        "name": "隔岸",
        "artist": "姚六一",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1456443773&auth=d87f22709201cdae56bd504ab76490543b84a9b8",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165071456067&auth=facdff6e3f23660aef14b8ff27c82ae94ba86de1",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1456443773&auth=6e5964c82085340fed8b6bb2fd52bdba49613178"
    },
    {
        "name": "情字难",
        "artist": "糯米Nomi",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1390466212&auth=60f5a1a9fb8b7e64ae1d43605ea4ee4a27a6c596",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164358519634&auth=6167e3a9a1be7390e68ff5a192e18b81289d83da",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1390466212&auth=c44f0b378c9ee2444d80c6861802cc6bde8554a6"
    },
    {
        "name": "风月俗事",
        "artist": "苏子凡 / 解忧草 / 妖狐公子",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1378212445&auth=ace881c9876013f606aae215fa110ac2001d4a50",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164385990360&auth=556a1a95bb19d1285cd09e4ec3d20435aa318dd9",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1378212445&auth=6e4755102615a7cbb51e78f366ad19c0e614e9e1"
    },
    {
        "name": "你是人间四月天",
        "artist": "邵帅",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1344897943&auth=d69de2e065626808b623163c6d1a66a1b3d00963",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164252455813&auth=5d864f56c3755512b996ca0440e7f984e01ac87a",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1344897943&auth=797f99694079927f2690b95892557c559d46ca81"
    },
    {
        "name": "收敛",
        "artist": "不够",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1435449062&auth=f2859f6a25449aab43c47faca15923007ff1c202",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164853155233&auth=c8b2371d3a2bbc9cd9cead3cc31c2c780f09e66a",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1435449062&auth=ac7329409f11e9db97b7db3657e68123438af3f1"
    },
    {
        "name": "你走",
        "artist": "李宗锦（松紧先生）",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=558071673&auth=0d72895bee8a0222974dca4fa7612109f61e9236",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163285806937&auth=dc20db5a74de1d4b415622cf68b108881809cd2a",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=558071673&auth=70a14ca0a61c414751c1c473067502b396059ab8"
    },
];