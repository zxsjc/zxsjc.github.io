## IPTV  [吾爱云盘](http://52bsj.vip:81)

自用电视频道源，源有效期未知，不确定失效时间，测试。
肥羊直播源汇总更新∶[肥羊直播源汇总](https://youshandefeiyang.github.io)

EPG-电子节目单：

<https://epg.112114.xyz>

<http://epg.51zmt.top:8000>


## TV盒子软件

<https://github.com/o0HalfLife0o/TVBoxOSC/releases>

## TVBox [直接下载] [123云盘](https://www.123pan.com/s/RLY9-sS3pH)

配置地址选一个输入 [也可以下载本地接口文件](https://g.cyao.ml/tvboxlc.zip)

<https://f.cyao.tk/n.json>

<https://hutool.ml/tang>

<https://饭太硬.ga/x/o.json>

<http://pandown.pro/tvbox/tvbox.json>

<https://agit.ai/Yoursmile7/TVBox/raw/branch/master/XC.json>

<https://ghproxy.com/https://raw.githubusercontent.com/cyao2q/files/master/m.json>

## PlutoPlayer [直接下载](http://g.cyao.ml/app/pluto.apk) [123云盘](https://www.123pan.com/s/RLY9-YZ3pH)

## FongMI [GitHub仓库](https://github.com/FongMi/TV) [123云盘](https://www.123pan.com/s/RLY9-F4hpH)

## 盒子软件 [分享迷](https://www.fenxm.com/tv)

[PuffinTV浏览器](https://cyao.lanzouy.com/iUuuH08lt6kf) [飞视浏览器](https://cyao.lanzouy.com/irdJv08lt7bc)

[儿歌多多](https://www.fenxm.com/613.html) [秒看电视](https://www.fenxm.com/862.html) [神鸟电视](https://www.fenxm.com/908.html)

[当贝桌面](https://www.fenxm.com/626.html) [蛮荒桌面](https://www.fenxm.com/877.html)

## 油猴脚本

[破解VIP会员视频](https://f.cyao.tk/script/crackvideo.user.js)

## 阅读APP自用书源

<https://cyao.tk/yuedu/>

## 广告过滤规则

<https://fastly.jsdelivr.net/gh/cyao2q/files/filters/EasyList.txt>

<https://fastly.jsdelivr.net/gh/cyao2q/files/filters/uBlock.txt>

## A free CDN for Open Source

<https://g.cyao.workers.dev/>

<https://www.jsdelivr.com/?docs=gh>
