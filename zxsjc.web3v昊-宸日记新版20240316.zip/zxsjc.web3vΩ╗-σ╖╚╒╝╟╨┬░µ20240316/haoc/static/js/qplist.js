

window.QPlayer.list = [

{"id":27630154,"name":"昨天今天明天","artist":"赵本山","album":"赵本山小品辑","cover":"https://p1.music.126.net/WO4i8GBIWfEcKGKvTPoSTw==/2074778441637569.jpg?param=250y250","sub_lyric":"","audio":"https://music.163.com/song/media/outer/url?id=27630154","served":false,"cached":false,"lrc": "http://haoc1688.orgw.net/zjm.lrc"
},
{"id":422419645,"name":"月光下的凤尾竹(葫芦丝)","artist":"刘强强","album":"葫芦丝","cover":"https://p2.music.126.net/xx6yFWdbe6o2D62DA47SHQ==/3419481169085753.jpg?param=250y250","lyric":"[99:00.00]纯音乐，请欣赏\n","sub_lyric":null,"audio":"https://music.163.com/song/media/outer/url?id=422419645","served":false,"cached":false},
{ 
"name":"平凡的一天",
"artist":"毛不易",
"audio":"https://music.163.com/song/media/outer/url?id=569214247.mp3",
"cover":"https://p2.music.126.net/vmCcDvD1H04e9gm97xsCqg==/109951163350929740.jpg?param=106x106"
},


{
"name":"写给黄淮（cover：解忧邵帅）",
"artist":"西彬",
"audio":"https://music.163.com/song/media/outer/url?id=1343506065.mp3",
"cover":"https://p2.music.126.net/NeZEUwXVyNyoqacFSGWsdQ==/109951163832648101.jpg?param=106x106"
},

{
"name":"风驶过的声音是",
"artist":"海洋Bo",
"album":"风驶过的声音是（说唱版）",
"cover":"https://p1.music.126.net/gfLR-3TEncp1cOog8oUaFA==/109951168567036973.jpg?param=250y250",
 "lrc": "http://music.163.com/api/song/media?id=2041974276",
"audio":"https://music.163.com/song/media/outer/url?id=2041974276"
},

 {
"name":"突然之间",
"artist":"G.E.M.邓紫棋",
"audio":"https://music.163.com/song/media/outer/url?id=1323301365.mp3",
"cover":"https://p2.music.126.net/X7f92tSJ-b0_sC1u9tgAyQ==/109951163654227442.jpg?param=106x106"
},



{
"name":"孤单心事",
"artist":"颜人中",
"audio":"https://music.163.com/song/media/outer/url?id=1361988914.mp3",
"cover":"https://p2.music.126.net/0KCMOKHHbimwfdVvPPBpTA==/109951164034526943.jpg?param=106x106"
},
    
 
    {
        "name": "向云端",
        "artist": "小霞 / 海洋Bo",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2049512697&auth=0213b073a634452c52e30b8123931c75601ccd84",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168638913915&auth=3e1e624aea5f61fda2ecf095ed0d4b18bd74f3ac",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2049512697&auth=31ccd579b03ed727352e85c53ecdbf018b60d6f5"
    },
    {
        "name": "诀爱·尽 (LIVE版)",
        "artist": "盛宇D-SHINE / 詹雯婷",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2054298885&auth=981aa593b5e899d4134b131123fce0ec008d18f6",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168667656773&auth=0cfac311ecc65b257f0ada1cf851449627250d4e",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2054298885&auth=a9d98d7be796fe707fa4c91232f1a29b45d407ad"
    },
    {
        "name": "风驶过的声音是",
        "artist": "海洋Bo / 费米Frieme / Zy",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2041974276&auth=db8f344130f7685f304d1c26167b5a721e343581",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168567036973&auth=6c9c08e28c7ffb9bd38a777ef6a7823294c35bab",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2041974276&auth=66f5fbc6fc2272efcd3ccfcdf7aacf55d7f79c44"
    },
    {
        "name": "我记得",
        "artist": "赵雷",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1974443814&auth=445b798583121e706c6794f21eeccc0c21cbca0f",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167805892385&auth=a49df27f9df5e46bbf31e0b48bbc84dc5eb41f58",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1974443814&auth=7b78cd1a148e2f95769d0c96b14b380e86d3ae24"
    },
    {
        "name": "雪 Distance",
        "artist": "Capper / 罗言",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2026224214&auth=495370af3ce5ce6f98a72b9e18a9d47a168fb0e3",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168431655039&auth=bc737b920d02af89299d31a33dc58622628fa99b",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2026224214&auth=ebac4281e0d6016f63d2121f5c563546d9110658"
    },
    {
        "name": "普通人生",
        "artist": "海洋Bo",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2041799838&auth=aec207273df9ad72869ca40e82a4ad987d211593",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168565288639&auth=9bdb82957fa8fb40863768e4bf5c7ce68e416fc3",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2041799838&auth=30eeaf594e33710bb7efcee5e0be1b04dd9306cf"
    },
    {
        "name": "把回忆拼好给你",
        "artist": "王贰浪",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1403318151&auth=8e3d82fc418844ceb2afb46e0d02ab31d9a1524c",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164485969446&auth=ba0fb57c0a20399a42d5ca4164c69abaa00aad2f",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1403318151&auth=735ac9cb2de19057adbbe1e1ad361848391961e4"
    },
    {
        "name": "罗生门（Follow）",
        "artist": "梨冻紧 / Wiz_H张子豪",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1456890009&auth=a7c35e9070d425ffa3c3b5da8ee18742a229058c",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165076380471&auth=40079646bac5267ad8537ac1c5c4dc9c518bcbd2",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1456890009&auth=de94f7e44bdf3d85180c319932426c85430cf942"
    },
    {
        "name": "Letting Go (Live版)",
        "artist": "吉克隽逸 / 汪苏泷",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2048584480&auth=cc6441af52382ed7f9cca5b5b644bb06c76a103a",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168622343007&auth=c7f1ff612372df23fa18147055b5e82a9d004b5b",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2048584480&auth=13d5e6586afe87e4d608ef99a5c19e5e167f1458"
    },
    {
        "name": "凄美地",
        "artist": "郭顶",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=436346833&auth=4b23df584240ebaa0fe8d1d55d050784d5d26df5",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=2946691248081599&auth=4b24e9b36b10690069c3dae45d3f8534ab80ad4c",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=436346833&auth=313110c2e6c26361effe73887ef23c3311cf0ef0"
    },
    {
        "name": "予你",
        "artist": "队长",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1895330088&auth=a989894b5f30d8b6be8e74d69db6ddb221a4e06b",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166625738075&auth=363ec6607d416655e09d87ea0f8717a4d961c1e4",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1895330088&auth=4f5aa2f16da42e07e2c1d3d2adf197bdbad25951"
    },
    {
        "name": "If We Ever Broke Up",
        "artist": "Mae Stephens",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2021343439&auth=31d30416917d846dce654486adfbb413c4a85c1c",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168298911512&auth=22b9266aa825281950121e8c435cc81449c18d86",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2021343439&auth=9500ef8b5eedc1bae0bb03bcd58bfdc626bec250"
    },
    {
        "name": "精卫",
        "artist": "30年前，50年后",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1951069525&auth=350b2519b2d8ed3802e1543136aadb9c32a49303",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166786983190&auth=38eb0ebde3c61c9abadd4a58923f004c8996b609",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1951069525&auth=260593816b90e47624ac7b13e44c0b4ea108192c"
    },
    {
        "name": "我的美丽feat.海洋Bo",
        "artist": "海洋Bo / 高睿",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1979417838&auth=6628c8c2b18225fde1fb3613a3bb2a1d56e8846c",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167854450663&auth=3a20102cafd21473ee5161f5c3a55b0f815f6148",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1979417838&auth=ddaf99845006964ff5ba041ede99c742f7b57fb6"
    },
    {
        "name": "想想就烦",
        "artist": "Mikey-18 / 缪礼丞 / SevenJ李百万",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2045117743&auth=a7ccf02a55739284aacd73a2a082a30d530189af",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168593212640&auth=64570f5f4f4132193381e4ffbb61528d3ff99ada",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2045117743&auth=024fc55077f97aa67d551620cbcb616051225b13"
    },
    {
        "name": "达尔文",
        "artist": "林俊杰",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2019573476&auth=fc76d4a7f22ecc909a35bcaa367f87331d426e8a",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168466764238&auth=4dce178e37cbed08c063e0f05eb8961cbe85679c",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2019573476&auth=5bf94c6ab5bde03b407092f25c1f625f0672b4f4"
    },
    {
        "name": "在你的身边",
        "artist": "盛哲",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=475479888&auth=d568fdc45c2e33810f33832de30ee223d6b7d371",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163191178425&auth=36cc80bb4a113fa1621c8f9d824dac2bd0936e4c",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=475479888&auth=e24abd563c1cf47a0423c31864966311a8cdef41"
    },
    {
        "name": "Self Love (Spider-Man: Across the Spider-Verse)",
        "artist": "Metro Boomin / Coi Leray",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2052349052&auth=aea0cefceaecd67594b1a7570627e7644369add6",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168652317597&auth=58a1aa356d9f519113716e474aa8942843f82914",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2052349052&auth=b4b39988623d15092d19c4f968d4eebfef4b72f5"
    },
    {
        "name": "如果呢",
        "artist": "郑润泽",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1842728629&auth=150eb0b6f11a8818351f632d40d104f27df17c2a",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165953469081&auth=14e482c76806bd31b09992fce893c4e67f7c99c6",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1842728629&auth=c5959a3aec6ee407fcf4189ff663b9fa92c5797e"
    },
    {
        "name": "唯一",
        "artist": "告五人",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1807799505&auth=32d77063b79ec3281045edb3fcff3b9d7218b2b3",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165585701063&auth=261a2a0bb0e38b4e89bfcb3b193ed4bdbe50c031",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1807799505&auth=a2bc34d27f3fcaa819d78ef5518f0b3122d3127f"
    },
    {
        "name": "我们的歌",
        "artist": "刘大拿",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2025533834&auth=24d1500fb4afd32b56252795c77f8cabd3e524e8",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168428025131&auth=ad00eda2ee53ddeacbbf6d503302000079c83bab",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2025533834&auth=2fc81e42f4976156c49a284efdc9933995a1148a"
    },
    {
        "name": "翠花",
        "artist": "DP龙猪 / 王云宏 / 陷阱表哥",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2046829307&auth=ddfdd0ac5acdacfd9bdc2d34bf23360d947efa6e",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168609119370&auth=b636e294bb3646b6dc6317f3175b0661ea1e640f",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2046829307&auth=b08ad288e5f55dbb781a0ba1ee4050699f009089"
    },
    {
        "name": "可不可以",
        "artist": "张紫豪",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=553755659&auth=c0101fe3692fd53701e20ddcdc808d0065a6d536",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163252847249&auth=90782ef49f60dfd34e47d9f204ccd8f0b21f9613",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=553755659&auth=1d2fbc27338a4b5986aad9e3abacd72386a54a19"
    },
    {
        "name": "可能",
        "artist": "程响",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1950343972&auth=943eb8cc40272fff3e90f674030a0534efa6aaa8",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167570919875&auth=3d09f5d9f85d1a5ab92a1f860d2b13a5c7fe8b85",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1950343972&auth=f332f6ff9236d728f55a09f18fbc49b2ffa7cb5a"
    },
    {
        "name": "字字句句 (Live版)",
        "artist": "张碧晨 / 王赫野",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2046990697&auth=b1ace3821827e3026f1050f41dc4836a7fcf556c",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168608653311&auth=fe2ad104f6ddca2b4a968116ff5f78887ced72e7",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2046990697&auth=1b870be0eaab1d754a0e26490485d047e6fe9a55"
    },
    {
        "name": "哪里都是你",
        "artist": "队长",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=488249475&auth=1c471ea4bf5115b32d55801ab8e24ab7df184c47",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951162964628408&auth=dfa4ad9f877c963c9a3176af6ce314ef5615d111",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=488249475&auth=ac833b8968691606398779684cb4efdbe2c3e4e6"
    },
    {
        "name": "若把你",
        "artist": "Kirsty刘瑾睿",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=865632948&auth=0c850f03d7ad66860d82d9bd766e8c9e00e19a1a",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163401482434&auth=f4d8caf9050d56cf9bc4b933334b2a25d6d306dd",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=865632948&auth=15b19ac4f225c498ee8e19a6c4163e93b9af5e3e"
    },
    {
        "name": "苦茶子",
        "artist": "Starling8 / MoreLearn 27 / FIVESTAR",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1922888354&auth=46d22b1921815c4efd691f46a701fb0b4c8d24f0",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167852652412&auth=95960167115dfbdfca0897b9a87100088c897688",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1922888354&auth=8764c65bcb2a84f39e06ef53e08c44f9d4d83fb9"
    },
    {
        "name": "就让这大雨全都落下",
        "artist": "郑润泽",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2024035483&auth=1584f3f75427ea006a5025a0fdf4120aa6357be2",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168326085019&auth=bb404d0ad7197544123ce15d8ae1d458d67ab64a",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2024035483&auth=32482ccdddfc0acc216a8e4f8d3eda348228178c"
    },
    {
        "name": "开往早晨的午夜",
        "artist": "张碧晨",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=449577636&auth=324168243034991963d7927261647694abf5c9a0",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163940907760&auth=9d6ae56781e0b0b60d137a2071fe85e52db1fc24",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=449577636&auth=7bcec9f32994f0e02dd2c0197fbb0489efbe602a"
    },
    {
        "name": "一般的一天 (LIVE版)",
        "artist": "Wiz_H张子豪",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2052441038&auth=559e223a42de70938ee779190a56602fe7862442",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168652792403&auth=e7765d65aa3a491b62ad0db8cbe1c27d7caa68bc",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2052441038&auth=4100f56fc8fc1e7afec68ea9ea88235fd3ead469"
    },
    {
        "name": "还是会想你",
        "artist": "林达浪 / h3R3",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1827600686&auth=92a8ebcd56f8d361ce700ce59e474aa968c78a08",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165798773745&auth=1a40147671d9f760117f9828549dd9c03d1d9bdd",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1827600686&auth=348823e6ceebc859fd36ecfebda14d3a9fc23915"
    },
    {
        "name": "暴风雪",
        "artist": "姜云升 / 艾志恒Asen",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2055215378&auth=e635dc9b34023bc6d50ba100b9038f35fd1d9c2e",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168649207060&auth=8c01389d5d583164403547b70e23abec91b4f0e2",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2055215378&auth=b4bc65eb3613e62eb698813116e7ca661c369433"
    },
    {
        "name": "水星记",
        "artist": "郭顶",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=441491828&auth=34dd9eba739e995bdfe88d34ceccead4c5550fbd",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=2946691248081599&auth=4b24e9b36b10690069c3dae45d3f8534ab80ad4c",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=441491828&auth=670615dfb8461595c934f243d9167da3f3ce4e8b"
    },
    {
        "name": "Letting Go",
        "artist": "蔡健雅",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=208891&auth=d373b878e2b461481f484df31d526fc915019ad3",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165561227373&auth=5923d650e0a69fa6ea198ebb055493f28335dd6e",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=208891&auth=bb38676d1dc490f2a72942e5183d2694beab3910"
    },
    {
        "name": "起风了",
        "artist": "买辣椒也用券",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1330348068&auth=ae463ffa59b0c1be18fe552e7ad80d6b779d9223",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163699673355&auth=203979f0540464286450b47d29f94b1b8f1e602a",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1330348068&auth=a45e8b4c9a036ac35766c450f36197d42fa330c9"
    },
    {
        "name": "小河淌水1952",
        "artist": "法老 / 龚琳娜",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1965928052&auth=b0441a1dd8231e831eb353c1668d94cd0179254a",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167750223899&auth=21e06166ec3fec812e9ab76812c10b45ab1bff32",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1965928052&auth=5427d541b85ef3d03e2c77f611047c201fcad01c"
    },
    {
        "name": "小胡同",
        "artist": "郑润泽",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1926623288&auth=ea21c4e06ad052956e51a9eb07a0161149605bfa",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167129280730&auth=fbf3770da4b7de91f1e6ab33a81e11d85462af0f",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1926623288&auth=490cea819991b2b930f2f9d00df38384a2ebfb26"
    },
    {
        "name": "只有你",
        "artist": "许嵩",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2055575000&auth=dac5cdce77cc15a2706662354a1ba7a213e2e4f7",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168677658455&auth=a22ebfd8196a84778bb0368f7de944e3730458f7",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2055575000&auth=d51cf190e31af12640996b076fb92dc9fff4a17b"
    },
    {
        "name": "孤雏",
        "artist": "AGA",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=421486605&auth=a7122067a519748a15a98d69e16a5bb6a042e178",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=18302470556355853&auth=358c96352a11b5c88aa0bd03fef5ebc3c93f7a58",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=421486605&auth=0b690b3c38a5347131d12c949e0b414dbfb8a64c"
    },
    {
        "name": "夏夜最后的烟火",
        "artist": "颜人中",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1482867143&auth=95cc8b4680962132517fd0955c2d24c04e4e9553",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165349625690&auth=1c2a46782727950611332958510d4acfdfb5ffad",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1482867143&auth=046e01839baf8a82ac92697be26e0a248e7ade06"
    },
    {
        "name": "姑娘在远方",
        "artist": "柯柯柯啊",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2022196813&auth=50d5bc49139591d4fd022561964b1baa06f24ae7",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168307420773&auth=3b986c28ccefc7eec8172f3348b681b29d6e90b5",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2022196813&auth=fbe24125173ff2628bc84aff5388e6e3c32159ca"
    },
    {
        "name": "就让这大雨全都落下",
        "artist": "容祖儿",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1984475097&auth=26c253462dfc391d17293eeb09c31aa480899595",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168296440959&auth=3ac905368d1a218754636c5f251a4816c9c18014",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1984475097&auth=37f582959c0bfff0e705ccbc8f0bb810993ac781"
    },
    {
        "name": "爱人错过",
        "artist": "告五人",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1368754688&auth=7a5d8c2abf404688066a184cf2f6ad39d389f2e6",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164111703663&auth=62dc0ee771d0434681bc50f9b018a17f245b99d5",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1368754688&auth=a1deef83685be31875017078c47edbf7f05678a0"
    },
    {
        "name": "带我去找夜生活",
        "artist": "告五人",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1410647903&auth=0705cc9fa62947882eca1d626159ec7f4599c557",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164567402626&auth=efefa078261b355f645ec1b69c74aa0589c14922",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1410647903&auth=37d70c649ca75f501043e0fe807a70ba32f017c7"
    },
    {
        "name": "多远都要在一起",
        "artist": "G.E.M.邓紫棋",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=30612793&auth=8dc513b8962192f7e5faaebd66d2c33b35ec3a3b",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=1364493930777368&auth=b3cd91fbfd4822618a42fe6e07623d09b3904836",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=30612793&auth=1e79cd34d8799f6b02f5f247123da670667f9c0d"
    },
    {
        "name": "Dehors",
        "artist": "JORDANN",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1815725297&auth=c7208e86e3c628f6512dd1ce8bed313c187e2f8a",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168356159879&auth=a8efb8d1b248759be36193775dbf528955add255",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1815725297&auth=b5a0b4c17aa22b2f5b7ce84efeb00d570f7163c9"
    },
    {
        "name": "天外来物",
        "artist": "薛之谦",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1463165983&auth=924fe7c56cbd7cf01f5ec9bcbfaf8ac70f898a00",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167040040692&auth=85378554a4777b66e3479feea91d9866196dffbc",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1463165983&auth=8508e3fa53d83be61b7311f8f6af8f5ee693f023"
    },
    {
        "name": "致你",
        "artist": "yihuik苡慧",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1867217766&auth=501bf7e1ae6f98aaed5df2a439c7f610e141749f",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166254691365&auth=bd17aa5283d0151f439f6710d2c52611724d417f",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1867217766&auth=d5007351f9a1369a01c02a862bd3f433b2c84eda"
    },
    {
        "name": "晚风",
        "artist": "7copy / BT07",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1441758494&auth=d1955cc4b0555928363c5f5c9b36202817131fe7",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164919449758&auth=c417171d5199730fc632feb38d205d3d4da059ad",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1441758494&auth=613ee2966462aba07d119db8f953ad76d6a58847"
    },
    {
        "name": "孤雏",
        "artist": "高睿",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1981557398&auth=dbb3da7636a82a6be81615faaee4cf0de4d9c8f7",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167879363210&auth=bb1c21fa886c702c77a0b2d62518e908ac2aecc3",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1981557398&auth=4cb75342c33fc3e98e06e9aa045d2b5e4d649a77"
    },
    {
        "name": "忘不掉的你",
        "artist": "h3R3",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1851652156&auth=afbf9e36b0597c36ff2c0e1aa19aab032e453fca",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166071009318&auth=c9984df1d06c985d6fbce5f881429a824d226310",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1851652156&auth=414fc4bc34efdfff06b104f8c3dd0a21a06c2ad6"
    },
    {
        "name": "第三人称",
        "artist": "买辣椒也用券",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=502043537&auth=037a558e4aa52bb64f2117cfda51b8c6987877b0",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164379891919&auth=98ce5eb2876a2fcd70e33b24e10f31195f23b28d",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=502043537&auth=b78192b6420b1414f7dc8ab3ae6a62c0a190bb96"
    },
    {
        "name": "Letting Go",
        "artist": "刘大拿",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1923184888&auth=e48b85875d9b388d72434294ef39249b1dc2c573",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167087160304&auth=52c9f4d12018cf1b32fd66ece49e097c5071bc00",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1923184888&auth=d0199e86ca9203d8f58efd87a94b309bd23a8543"
    },
    {
        "name": "悬溺",
        "artist": "葛东琪",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1397345903&auth=06f86fb151c8cd975201400d157f93a4af3e6ae4",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164166513349&auth=efcbf9bd426c326be38b77c03499fddb0437f383",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1397345903&auth=8f432b1d8e47f859e2f91d11f2be079f9ad6f800"
    },
    {
        "name": "给你呀（又名：for ya）",
        "artist": "蒋小呢",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1497588709&auth=25b378b8f128cd39739dba51629c843d019e2a1d",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165494781109&auth=5a139ce0d7d7e49bdca36463cbe126289c512abe",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1497588709&auth=a1875e965dbcd9141a9c17d316064e6b99e25c27"
    },
    {
        "name": "BABYDOLL (Speed)",
        "artist": "Ari Abdul",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1932769322&auth=d7eef93d813eb783766f065b77f2ee1087f0ae36",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167210282652&auth=683a02eb5d98dd3984e6d48592bacacf11f813e1",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1932769322&auth=dee8dd23e5c8a32534e191b607353b9a10706f24"
    },
    {
        "name": "再等冬天(Memories)",
        "artist": "h3R3",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1927693793&auth=c7165f09a657ba89f62474e86f155a00308e7ded",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167578505822&auth=4032d13086061c872b429ac6dae21c8bddc6f8ff",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1927693793&auth=07a35b44b6aeae3b5229f3ca0203ea9d17df7581"
    },
    {
        "name": "golden hour",
        "artist": "JVKE",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1958557540&auth=878f4532602f58e884f840c0e37e02a26e66bab5",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167909857256&auth=693e95a7aa7573fbd7987de6aea400e6ad08a818",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1958557540&auth=6a27ce23a6dffdf244aee37b23bf3f03ce37fd42"
    },
    {
        "name": "算了",
        "artist": "Vinida (万妮达)",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2052409208&auth=b07d2850d730eadd468da5d3714ee875b64d0c55",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168652596542&auth=a994af639c4b57723dec0e0a0e0d40630eb44558",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2052409208&auth=8a3b74dcc98298d449abdaff05aa901f5e3de417"
    },
    {
        "name": "总有一天你会出现在我身边",
        "artist": "棱镜乐队",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1303027499&auth=c65d46102c30257b778c1241b56cf27e5e9c2f22",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163598901405&auth=7cb350ce922492ae7dd9f4fb6f80b6a40d680d81",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1303027499&auth=86a707c9343f9db89db4fe236dc40785438621f0"
    },
    {
        "name": "再见莫妮卡",
        "artist": "彭席彦 / Franky弗兰奇",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1824045033&auth=52a22085ed10fa0e434c940a25478883f5756769",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165770805050&auth=aa4ed8051a453ae914b34c52ec0e6013eefb9e70",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1824045033&auth=c8bd24821b0622556c2c1f45a9da264a9f2656c5"
    },
    {
        "name": "Empty Love",
        "artist": "Lulleaux / Kid Princess",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1435828582&auth=191efcd7258996f2e54d90a455941f3ea9dfb4bb",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164855840145&auth=a2b5d5e492115a11a88ac0a7f300decef813d3cb",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1435828582&auth=e6abf446824eae8831c22a5071bfe61b0ac97034"
    },
    {
        "name": "11",
        "artist": "队长 / 黄礼格",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1907766514&auth=66d881853f10df144e19dae06cc79e95a7e7625d",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166868150028&auth=1bdff34c0b5e57bc81f75c404412ec464b548387",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1907766514&auth=f819aaa12e237a7ab1997c8e62b2186b960a1cc5"
    },
    {
        "name": "如果爱忘了",
        "artist": "王贰浪",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2021373243&auth=887054612176559812c190090a868065eddfb7da",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168305751852&auth=1da7c5843f9ee8ff4314a6ef0a2f884e302420aa",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2021373243&auth=74cba14456100b1feb583da67a2c6b15a32149f2"
    },
    {
        "name": "形容",
        "artist": "沈以诚",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1336856864&auth=26d3955b292cc8adc75a8bd550139edc57d74b5e",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163957708692&auth=4d58c9077bc302e092597246ac57b547970fb2e0",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1336856864&auth=d21642ecf812aeadfda2c8c38115c0bac7a9bdb6"
    },
    {
        "name": "一直很安静 (Live版)",
        "artist": "毛不易",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2053617878&auth=1c9f4186f975f212b9f8f9f23c329640371da4c6",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168664051361&auth=b5ea1408223ec2d1d660bb7764a47b888089e5d9",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2053617878&auth=b9b707250fb9f5382135cea508bb129ed8784497"
    },
    {
        "name": "吻得太逼真",
        "artist": "刘大拿 / Wiz_H张子豪",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2034881346&auth=8ecec746e6d607bdb481d53148da2f1d3e0fbb35",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168507667265&auth=6bf04ab62edc22d3ee9253b04a196acf995802c1",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2034881346&auth=6fb1224268f285fe922cbd75387d4d329a6e2464"
    },
    {
        "name": "小城夏天",
        "artist": "LBI利比",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1934251776&auth=7668a56d1c2b9071502e471ce0b5ffb8f1c569c4",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167350445378&auth=cdbf96567f879435387311e266955892e6e0e0df",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1934251776&auth=6358bb3a127988839a1bad35124d83abbf4a0396"
    },
    {
        "name": "想去海边",
        "artist": "夏日入侵企画",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1413863166&auth=76913ef3820e076be6721fed742c874b2e34adb6",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164602081973&auth=7f500872ebcd89fd83636e7d59f9439301606c60",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1413863166&auth=005a23c4bd9c4803f502eed90be273a3c7175e01"
    },
    {
        "name": "Daylight",
        "artist": "Seredris",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1372188635&auth=e209bffdbbf276647887deb3586354ec4d0c0a88",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164152228527&auth=8ba3a4564a0339a1d86f1c13c9bc21bcb3eb7733",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1372188635&auth=d2ad81e3b51e8e6b122fa0652f9557fc7819e81d"
    },
    {
        "name": "晚风心里吹",
        "artist": "阿梨粤",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1929370102&auth=0f1176c124f6e309808242bbcbfc1198d88eb45f",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167297344637&auth=fcdb86bb3e66fa657ce26fc0a0f92c13a43ff3b0",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1929370102&auth=d858940f3802e1ed0ddd3ac8cd490bff5f36471b"
    },
    {
        "name": "Shadow Of The Sun",
        "artist": "王OK",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1968791360&auth=0541b8fea6821a5fca3561018d0987903392602a",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167799604909&auth=72bebda412c8db3d4c3cf876f6e2c1db6a5917a8",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1968791360&auth=855889e3cc41ca8e4b31f6a348858c28662b81e9"
    },
    {
        "name": "三拜红尘凉",
        "artist": "尹昔眠",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1969320038&auth=4ddf14dcd9d0955e76c3c209e0e5dd94bf3693ac",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167743445530&auth=5a050c90d3f562e7700056beb5889f0804684763",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1969320038&auth=d0e9a94dd2fe39554a59e7ddc6f5269cb2fd441c"
    },
    {
        "name": "就让这大雨全都落下 (Live版)",
        "artist": "汪苏泷 / 容祖儿",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2043125519&auth=be201236c9e16081e4c7606e94f200ba8745d1e1",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168575643881&auth=894f470a075cb4c9439a30f1820a39906305f398",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2043125519&auth=a0f7b2cc0538da0666694140ebe1b22539b9efd4"
    },
    {
        "name": "Slow Down",
        "artist": "Madnap / Pauline Herr",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1356658022&auth=c07c01a1bf78061d2d2e0788ef3b182ebfa27480",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163975730949&auth=a2b93f5d81c294d4413feabb5bdf55300c47830f",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1356658022&auth=186d86c9b0fb2b9ceaeee1b13b48a98143ff5bfb"
    },
    {
        "name": "是你",
        "artist": "梦然",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1966162185&auth=1d78843cdc6cb937e81e9574ce45672c3b409f8f",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167704212151&auth=815fa55b0e426d6a051eee7b556c968509ca1199",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1966162185&auth=faad85dbf348f9dc2be9254b246b7d4a9a192ca2"
    },
    {
        "name": "乌梅子酱",
        "artist": "李荣浩",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1997438791&auth=6116528bf25d5d407479e95d61820f3e7fa5ad69",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168159576909&auth=412ff639ecb3239169e49c1b1e00a50e53002bc0",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1997438791&auth=bb0c0ad8d04d26c35052e61159ca7e71c46df376"
    },
    {
        "name": "晚安",
        "artist": "颜人中",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1359356908&auth=e9593decc5b9bc5a3f9d5aa9af057f1f8eb7e9cd",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164007377169&auth=8f28de08a5a57330592841ca6ac5820ea0accb10",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1359356908&auth=2d24218b22eca319294ba38f7f4c74e7a5424bbd"
    },
    {
        "name": "还是分开",
        "artist": "张叶蕾",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=465921195&auth=ef65df388fd1638ee8a447cf7aa158816fdceb29",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=19218363741925314&auth=4a40816ceade37449a03c4cebaacfc58b7a827a0",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=465921195&auth=28b9415fb4033e8721a24b7da4d9a68bf752ed0b"
    },
    {
        "name": "Wake (Live)",
        "artist": "Hillsong Young & Free",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1873321491&auth=edbc4356d4aa00e735227c75a7e2ed4123f9297c",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166328143737&auth=89e03b120ed7be3938ab2200f73132798f1ecd0d",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1873321491&auth=0722cc8e31d48f63117e5f06f6f45d2e7428a34b"
    },
    {
        "name": "暖一杯茶",
        "artist": "邵帅",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1371780785&auth=1e801c184f3d9533e7b39480b6c45264e0616c40",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164151547523&auth=d95a0fc898276c42abf44941ab800b98682018ad",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1371780785&auth=fd0f8109205cbc7cd9da01de0272431c8e07d89e"
    },
    {
        "name": "最后一页",
        "artist": "江语晨",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=247936&auth=010a77c21468026f0eaa011512f3b3797d1a41dc",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163610134059&auth=f588f7a4c91fef7e25aabb9f08c2942123d3ed57",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=247936&auth=899f90bf00c5739ad68c70b95f3f680eec942331"
    },
    {
        "name": "武家坡2021",
        "artist": "龍猛寺寬度",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1891431677&auth=edd58db2eff2fdc3c9276cbdb920c6d485e07221",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166577778160&auth=d730d63b3d10a2e62c57bc140b636beef38c199d",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1891431677&auth=0af95a168e73f86bc773436ca6d29cece55a4586"
    },
    {
        "name": "STAY",
        "artist": "The Kid LAROI / Justin Bieber",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1859245776&auth=cdfeb4659b01718500415dd037bc64c8915a37ca",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166155165682&auth=cc161cc0c6941d2b03b560d2189765ae65c858d9",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1859245776&auth=6b8622346f88a52c5ddbfb010b1dab1028043ef2"
    },
    {
        "name": "一直很安静",
        "artist": "王贰浪",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1968781675&auth=d86c9f7fad8899bcbcc7708f35bb610cece838e6",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167740623345&auth=26602f19be1ac04d1af1c14c97f384ecb2b611a4",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1968781675&auth=d8381364de94efa1f1e8192942af72c4304bea4b"
    },
    {
        "name": "与我无关",
        "artist": "阿冗",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1413585838&auth=422a520336a6305d04dcb907f6d10af1c7016796",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164597332931&auth=99c6d023927a881b134cc79ce747233b82a4b2e8",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1413585838&auth=0a16a64f12d08f251f84f08be29968c8929f7299"
    },
    {
        "name": "沉沦与遐想",
        "artist": "C.HØPE",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1492584510&auth=aefea53784ebf4e517fa168cde1436a5bc941103",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166179751996&auth=16cb43bfad1c1a48676cb6b1f4853c8c1b20ebef",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1492584510&auth=961128f244eaf691f0a0e17510dde7600b3632b0"
    },
    {
        "name": "Alive",
        "artist": "张艺兴",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2047743493&auth=7705ca5b83e35c86f7cbc86e986c8c4c9fe70deb",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168616309452&auth=7e099c5679f886cb9d39f201d5c05c3ed23b0823",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2047743493&auth=badce478aa0b6336280b5642fecb8ac4698a8ac5"
    },
    {
        "name": "初恋",
        "artist": "回春丹",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1873049720&auth=78e091b5a0b26f6a270a89972ff37f3ed1a48159",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166324714668&auth=068f4e6d486af13107c5772fb7a378eb73a4e8d5",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1873049720&auth=1987be85f138dcdd4abfa2cda0fce7c8c1ed2534"
    },
    {
        "name": "循迹",
        "artist": "王子健",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2018432856&auth=2d65256b7453dc0ea8d391c7dd2809146ab12b19",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168271926504&auth=d43f65f105e8d95b6914eb108dec3b77110f6184",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2018432856&auth=30f71148596572c68183e865aa3d52b89f500aed"
    },
    {
        "name": "电梯战神",
        "artist": "宝石Gem",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2048786994&auth=6ad3f7c9843f0f6495dfe7a7e2b153a817aaf7c6",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168623863644&auth=66a038f4f8702192efca5cb27e015262ad099225",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2048786994&auth=cde771791962771a9fe317afb64180ecd1bf849f"
    },
    {
        "name": "天若有情（女声版）",
        "artist": "高杰杰杰杰",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1931994283&auth=392f64b27bc2cdb9cb22c91a99b19caed16e7640",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167198487305&auth=bbc26bf217f6cd22bcb4211b6b1bcab61ecece67",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1931994283&auth=8c35b47ab08a079e8068a7f824a47b49b7d9fbd7"
    },
    {
        "name": "让风告诉你",
        "artist": "林宝馨",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2053099516&auth=762dd8cf8154f815ad7edcf5902a27db88c4ff0d",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168659324540&auth=3c498c2b7074c3ad1a14c077ec3a859d3b6bb450",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2053099516&auth=11acb7528202034c244d07254d812c3306d0be16"
    },
    {
        "name": "MOM",
        "artist": "蜡笔小心",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1387581250&auth=22d0a6c6887ae2143d8893cdf689fe25ad8eef0f",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164332837488&auth=f7ad5b9eb6c862cf82d79d44b18eb0b81ae3befd",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1387581250&auth=2b5dfdacc3276de695b3be2c632a70dbe278a0b8"
    },
    {
        "name": "会魔法的老人",
        "artist": "法老 / KKECHO",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1988564487&auth=cbea8ee996510281e897ae9b9471cc6322a1492d",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167957001651&auth=273df05b173a19cad29d31077b15c775850e7197",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1988564487&auth=c487ab70e344905459ba9561d718ddd0c65c411c"
    },
    {
        "name": "アイドル",
        "artist": "YOASOBI",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2034742057&auth=a84518f6ba373c254e2eb6e7ab26fba605086c28",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168573694568&auth=8fa679c433186d2e44495a73f9cfced89c428097",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2034742057&auth=43a2cbd17574207002e6292e9a0051f6a034d1e6"
    },
    {
        "name": "声音",
        "artist": "YOUNG / 刘思鉴",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2031085185&auth=54ec9bf909fe27ccaf752ccd841a92b27fa588b3",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168475709963&auth=f8131bd2c611c9adb49017b2f34a26182995aae0",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2031085185&auth=8dcd10a0e7742f65e6852d0bd7b1ed41f2e31dc4"
    },
    {
        "name": "像我这样的人",
        "artist": "毛不易",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=569213220&auth=180b123c8c045bf47a9c8905c847dd5392498479",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163350929740&auth=5048944625d50f9b61c499e47c3c0db76c2573a1",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=569213220&auth=ef2e8b1e7d967448958d8c57be186bc865fc7461"
    },
    {
        "name": "最好的我",
        "artist": "刘大拿 / 刘思达LOFTHESTAR",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1975753397&auth=b0a773e850408880e819dd958d9003e6aba784d5",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167823958296&auth=1e37f5ffc144ad35e8474a34406e0e243d5f8e59",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1975753397&auth=ae4fb5f849a20e1651cd00cbb5d94002b86b2b3c"
    },
    {
        "name": "你消失后",
        "artist": "姜云升 / 刘美麟",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2053122068&auth=9275b13938e4d72956fab1ac48058673b3131322",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168672724619&auth=7bc45ee47d4ad691e5d85cb68f6343c7aba3a7c2",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2053122068&auth=41c7d8e2b8e3c7dc8f840939b3b1b04756c59d9e"
    },
    {
        "name": "是你 (Live版)",
        "artist": "王赫野 / 张靓颖",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2050391293&auth=ec0e80f0ffad8172201b560b2e2dc31338fb48db",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168636982036&auth=6b931a1c307af51685959251148754a8af8523df",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2050391293&auth=859e63fcfed3f6827c95eb6919c93ce8fb6ab363"
    },
    {
        "name": "特别的人",
        "artist": "方大同",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=28403111&auth=4c9a6f1b02b31791ca59e98688e682a4f0b21e53",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166349819975&auth=b875588d802963d792338e1c1217f7aafb6f9902",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=28403111&auth=dd1fcb261a63951de2d3eb5d027e5873d49c1c91"
    },
    {
        "name": "忏悔录",
        "artist": "KKECHO / 那奇沃夫 / REDBOI",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1970396862&auth=0b915ad087f11d07bf367f9e236f002a60e2642a",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167757521194&auth=9bec3a11a47413242e45f88e1047213f23e39a84",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1970396862&auth=a3e869a8ad4dbe22e9ad64105c4a33cfec446af4"
    },
    {
        "name": "谁 (Live版)",
        "artist": "廖俊涛",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=566436427&auth=bfaa948e35c31f25fc2e6cdd20c5263adfbec678",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163315608239&auth=4c297c61d8fe2324512fc942cf73cc7e603bbfdc",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=566436427&auth=33a898334db435b90e8a07ad899d026712cb55d1"
    },
    {
        "name": "指纹",
        "artist": "杜宣达",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1887139866&auth=edf5db962229d4a24ef35b98a6b6a99255170d3e",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166578436098&auth=164dea89d0d7470d6a76b09639b6b454e620a6a7",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1887139866&auth=e7de1d2bfe36ff263c62a877bbfaa6d76f8948c5"
    },
    {
        "name": "天若有情",
        "artist": "黄丽玲",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=438204707&auth=206ed51fbb7117148dad567e81a5b3b153c9bda3",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165958851914&auth=842ca8d3f1ea95b8efb4810c0c698b51b082662a",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=438204707&auth=7fa48500d5dd7f24261400b8f2b165c7a56f4b4d"
    },
    {
        "name": "谁",
        "artist": "王贰浪",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2026812798&auth=5e8d7876ffcabe74e908906089ad4bd2a3bfc892",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168444393077&auth=e2df9fcabc330a2921c0a452819527886dabcb3f",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2026812798&auth=3603aa87ec832d8dc8a8cd8cc0911fc04187adf2"
    },
    {
        "name": "But U",
        "artist": "NINEONE#赵馨玥",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1459232593&auth=1dbdcfef63e3703e38bc606abae46243bbed55fd",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165100592039&auth=776400a44db7a9f39ba627cc321b8f9bf7d9c528",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1459232593&auth=47a996f68a8b1968fe4fde8848d150d706be52d7"
    },
    {
        "name": "你",
        "artist": "郑润泽",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1406083061&auth=613d9c95bcf6ce706210f34f361b8a7ec2996d54",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164512103081&auth=5618dcf1cc62113a0e2497822f97959d4c8d8562",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1406083061&auth=231ad74f58f0ed49e1cdd626ad5da9f65ff71cf2"
    },
    {
        "name": "下雨天",
        "artist": "与少年他 / 芝麻Mochi",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1426112587&auth=1d6a1b55eeb3b3ec0d5a6f6f8775cedb55ed3464",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164742550320&auth=a46fb9b11b7a103c47bd6a425b412552746089aa",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1426112587&auth=fa32343243d46b392383e75797444cc235b4231d"
    },
    {
        "name": "骗子",
        "artist": "文夫",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1924343459&auth=be13f2b54c661982267824bf913b1af0dc83f385",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167606181094&auth=c674394fae72206606f613c4e73e46c7beb5224d",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1924343459&auth=afc8bf4d7508d65e92c73dbf1e05f981cc64212d"
    },
    {
        "name": "错位时空",
        "artist": "艾辰",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1808492017&auth=a8bc2f1286cc4592c91bcdde0f8e97bd0a69a794",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165595770076&auth=e91478e342c997fd8d8e1781420a9930ed950402",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1808492017&auth=f7e84e8653fdfd5075deca5cc48c26c80573862e"
    },
    {
        "name": "三国恋",
        "artist": "王巨星",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1947948874&auth=a6e7daa1ac7032fee8a7264d763fea10f366d44b",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167435417002&auth=d5d97e80ca906f14b053ba4a5df4f259483053a9",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1947948874&auth=dcff5266d964e432ae4a4a81b34a5b3052b87ad5"
    },
    {
        "name": "消愁",
        "artist": "毛不易",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=569200213&auth=123309ee393cc7645add0bd9be8c273ed555a87a",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163350929740&auth=5048944625d50f9b61c499e47c3c0db76c2573a1",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=569200213&auth=ea7107a125bf1f43b266f9572f5cd06ec10bed28"
    },
    {
        "name": "爱似水仙",
        "artist": "苏星婕",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1975589384&auth=054dbe6da39639359810f59b2e83231d60440543",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167819332684&auth=1629abc12d08e5f4ef55e463c6d94f93bea8d408",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1975589384&auth=d362351a748ed2686949945e84e00a59fe6e3bd8"
    },
    {
        "name": "孤勇者",
        "artist": "陈奕迅",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1901371647&auth=f71b61be2e4eda6525b3e4275733bea882390d98",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166702962263&auth=55c8ed1b807040a2058d67d8abb3688f3e83ac6a",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1901371647&auth=50426b79877c5222d35b12692cc5c7271ad82af4"
    },
    {
        "name": "山茶花读不懂白玫瑰",
        "artist": "Lil笑笑",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2019620319&auth=2b09dd876945ead3ff37729c54735413a5750574",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168667327718&auth=3615fceeed87984ae14171d99d74d19b06ef6e39",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2019620319&auth=90fb522cd87b6b432e5620ae2f020383d631e905"
    },
    {
        "name": "世间美好与你环环相扣",
        "artist": "柏松",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1363948882&auth=81256530a1e04407635a217e6ea50020b4fafbeb",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164071024476&auth=e5f2b5f9b7840860f3c6a7d00851128e277055d4",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1363948882&auth=80129853dc64ca27c3837572ab98d55b88cc4710"
    },
    {
        "name": "红色高跟鞋",
        "artist": "蔡健雅",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=208902&auth=39db2e391573cb7399bcf23a2e5ed1045d178149",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166195459631&auth=5f94a36d8e4ea6c58a4ccae20ff422a3a0d7f2d0",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=208902&auth=6b480ab71d741487d21980485e8e0b6d86af2c25"
    },
    {
        "name": "溯 (Reverse)",
        "artist": "CORSAK胡梦周 / 马吟吟",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1294951288&auth=c69b837245923139180d2e43878a2592e17c0164",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163416029067&auth=837d54c527ad1d93f67bc8a78f29d52d816dd38a",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1294951288&auth=0501b1e830512b750d3ff1aa55bb2b34cee59aaa"
    },
    {
        "name": "算了吧",
        "artist": "Aioz / 刘思达LOFTHESTAR / 张天枢",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1908049566&auth=8798a6483defd2d88b6917243eb4a460cdfafc20",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166871655381&auth=d8cccc085305681e6ac9e94c59a8856857bc027b",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1908049566&auth=7ab5dcb4ae32c16f7b4f97f5aff5f9c1ec09c7b8"
    },
    {
        "name": "谁家",
        "artist": "池鱼",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2024225492&auth=9779e070001185de4412da3d9863b491ee561e79",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168485374854&auth=23ead387e5b4f05a77acf811a38728d51115bf7a",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2024225492&auth=9c1fb192f698acc6c0f5b48714ef8f0917162ec5"
    },
    {
        "name": "九品莲花",
        "artist": "OneOne",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2054965256&auth=491e3ccced5cfaad791d5fe732352d85143b1fe4",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168673673023&auth=0a06748390397ee3ad0cd93275583372fdf8ba00",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2054965256&auth=68800931635f6d0322b5229dff0842dc7f490371"
    },
    {
        "name": "Straight A's",
        "artist": "Connor Price",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1979382551&auth=d885bd21058692f424a868676f11c9de39c1976d",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167853769555&auth=e31dfa91ac4f8eb29b0955a6c197cd98180bf1d3",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1979382551&auth=ef2cd7ac4de90e55071a4de34a3e92c995981366"
    },
    {
        "name": "漠河舞厅·2022",
        "artist": "柳爽",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1894094482&auth=48af00531a61623ed1d93ab1fb941855ea364c7f",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166609630672&auth=0d8140205bab0570dc721d563d86692f49f9659a",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1894094482&auth=e9ef3c78d9f4bcdcfaa6371feafb5333471210f1"
    },
    {
        "name": "或许",
        "artist": "LBI利比",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1958031074&auth=cba382892c05536c1ce2dfa92758944e35209bdc",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167631833377&auth=5b60951837bc06943da4f2c02faddca6926ed6a4",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1958031074&auth=5ce65976efeca481c1d63f8234d6ee546ff81f3b"
    },
    {
        "name": "流浪·地球",
        "artist": "TangoZ / AnsrJ / 谢可寅",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2052782758&auth=7c7cbe28a33273bb87ed14ac2af7e3cdc63e45ff",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168655706792&auth=52395bbeefc934123d69f5046494c0bd0749ea7a",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2052782758&auth=d2026c6f835c5267592316116427fc0ae0cc679d"
    },
    {
        "name": "迄今为止的生命里",
        "artist": "姜云升",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2050620264&auth=13abf57dd387228fe27382173b79f19fb7927fd9",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168649207060&auth=8c01389d5d583164403547b70e23abec91b4f0e2",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2050620264&auth=18252ed9c8bdb1c8f9d49e900edf4d4afc5df38b"
    },
    {
        "name": "你要的全拿走",
        "artist": "胡彦斌",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=529668356&auth=9a5e0fb6c951d6c8e7ffb3b939ba0d97788c6786",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168111322942&auth=394e1eb504cd05475eb52444816a9b87977756c0",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=529668356&auth=595e2612048c83fa617b3a759270105006ba921c"
    },
    {
        "name": "火棍",
        "artist": "浮萍草 / 东北宣传队",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2052442439&auth=6a71baabdef50e65b27784c6ec103c7dc25cb05a",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168652832713&auth=94ccde0f324d7807e52a544a614befe8f353086f",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2052442439&auth=57d880d48298959ecddce0086fcfb096b9faf32b"
    },
    {
        "name": "他不懂",
        "artist": "张杰",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=28059417&auth=09c6881388f1975ab3f451b5575233514bb0b9a3",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163117902077&auth=ffaa8f8b9968cc9819505ca5cab57d536dda117a",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=28059417&auth=0b7e5d4654a0d05bf7f56cf9b2966bc2baad6a59"
    },
    {
        "name": "失语者",
        "artist": "刘大拿",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2006448864&auth=aaf36a26838ae67a1249a2176d001dc38250ff3a",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168150572289&auth=4557ce0e3f86ceaffc0dee2ecad23109e5ef5fc5",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2006448864&auth=22c3b4ede338213b68934cdac74a7e84320b6772"
    },
    {
        "name": "我曾遇到一束光",
        "artist": "叶斯淳",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1988532821&auth=37890c1263bb7c4524e74c67a09deac2fc080e1f",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167956644774&auth=2d6c50c8b847af12bf1596bcfd7ce202647d1807",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1988532821&auth=87c9174138aeb264839dd15c54fc5692136916f2"
    },
    {
        "name": "Head In The Clouds",
        "artist": "Hayd",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1878812258&auth=0a3afa12a88af48a0980f337c3836b6c94791c23",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166421319018&auth=d949110e98fe7fab131199c6f98abd556f9a09c1",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1878812258&auth=5076f54618ae89c17410cd3c6cece467bc5ee7e5"
    },
    {
        "name": "恶作剧",
        "artist": "林依晨",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=255574&auth=f1cb1f1a79613b5a4a6b09fd496e097b1fbb16f5",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165625481274&auth=e5f17fd5b870cb683c80670218a75b1de4f9f45c",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=255574&auth=b5abfc4443404b52b3c394161620cf2828f09a46"
    },
    {
        "name": "他只是经过",
        "artist": "h3R3 / 高旭",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1443838552&auth=61cc190f4f942df391fa35302c76426100a034cd",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165348116023&auth=4df8ae2b733f963dc7cb92871fdadb486cf51576",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1443838552&auth=b3e5f1435ba0fa3fafc21bfda58f8f925ec50737"
    },
    {
        "name": "Normal No More",
        "artist": "TYSM",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1440570723&auth=56b38288dc39ecd25b6d39e05f8c9d40bc862c47",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164905500417&auth=9073f847d652ac84dc622693b267cb0572185479",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1440570723&auth=2d116ff68cd770e30b7060e38ce328a3b3fd06a6"
    },
    {
        "name": "遐想",
        "artist": "郑润泽",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2018733994&auth=d2db12fbf6bf3016aec81017d86d524dd90938d2",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168408373477&auth=31c434c35fd6775595d3ca62b3de992190105ad2",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2018733994&auth=f6c2aa5fd8f873677998abf2043e7c3d9c99aa02"
    },
    {
        "name": "夏天的风",
        "artist": "火羊瞌睡了",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1436709403&auth=5d310532dd9b97de8ce926a9fde04d7d6f3567a2",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164906689206&auth=a27683425c4cfa5f77d8af6571663f96ea0da650",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1436709403&auth=4df0ce9b203b15fc9776974a8e8724b2cbed381c"
    },
    {
        "name": "身骑白马 (Live版)",
        "artist": "张杰",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2038508476&auth=7e9b0cc96e7f0b8b5326047b2997dc13729ef493",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168540070885&auth=1dc36c37c68640256ff620f5a7ea93457c1331ef",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2038508476&auth=35e322cd304460f3a66407e08391298fd8389571"
    },
    {
        "name": "危险派对",
        "artist": "王以太 / 刘至佳",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1877996649&auth=144df662fe39d1d868fe37592664f4bf56ac53e7",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166516282895&auth=6a4149604fdf6cd2e88fd1543ff926aa53491251",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1877996649&auth=43a87bbd580c42c6a7b84ce64b1fbd76866a1567"
    },
    {
        "name": "妈妈的二十岁",
        "artist": "海洋Bo",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2045946501&auth=103964156f1c39d104ee02d42d9e828b44825508",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168600536093&auth=d7f532588bb0cbd625ce641554b0f2c766f298c5",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2045946501&auth=18076f64f79a528591d59de671ebd2b0a4f90c6f"
    },
    {
        "name": "So Far Away (Acoustic)",
        "artist": "Adam Christopher",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1313584359&auth=95f97584ed255654be4af610d6d91b997a406d13",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168291209486&auth=e49c34cfb4c1bd71a295589315dac918329fd907",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1313584359&auth=2b9da0191001627006c7176a7399d053e89fb08e"
    },
    {
        "name": "Love Is Gone (Acoustic)",
        "artist": "SLANDER / Dylan Matthew",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1401671455&auth=35ccbea2037b582acd6fe2368d4d0dc326290bf1",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164473460772&auth=f34ff580b95576f6e02d87cbacb69bb6a4700e70",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1401671455&auth=2f75837e309a150c7adac3f63b1c1d6cfc30cbbe"
    },
    {
        "name": "入秋",
        "artist": "RAMBO GANG / Trakin(Tk酱(*^o^*)) / T-BONE / 江楠江楠_",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1477144603&auth=9cf0ee6cda065ffe8f34d3ba3fcb219d42ed1e17",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165005286070&auth=8499e523f61c2697b6a710aac6fe157c2e8e97d5",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1477144603&auth=c2307cb18ce6c7a1579f2fd7caa11533ee34c6b0"
    },
    {
        "name": "Cupid",
        "artist": "FIFTY FIFTY",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2025227742&auth=e50f8e017c61c4944c081010043a41dd41781747",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168521959745&auth=be2ec1dc40bed74ed3af676504f536fd755eb3c3",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2025227742&auth=474f204637b0fdc4845f124719454fb042b291b6"
    },
    {
        "name": "我知道",
        "artist": "By2",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1430303185&auth=bdc5137757031d2686f6ca6fa6e3f37f89cc0330",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166118947252&auth=55aef2f263192388f9ed59a657f79862147030ae",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1430303185&auth=299df50513d518780c5a741921d6460bcd7f2e1e"
    },
    {
        "name": "梦醒",
        "artist": "handsome lau / HYPEEZY / 冯泳",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1395222212&auth=bc44a2eefdf241d3b942932c5c991220f59f9dc3",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164409713563&auth=da248132d729c7b4179d1dae9c7324755c58e583",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1395222212&auth=b3b7d04d492da53d70e984f027fd41933d16c4cd"
    },
    {
        "name": "Cupid (Twin Ver.)",
        "artist": "FIFTY FIFTY",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2025227743&auth=3d55fc5571b2f90ff3c53df40f3a996f174e7e69",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168521959745&auth=be2ec1dc40bed74ed3af676504f536fd755eb3c3",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2025227743&auth=6215ecdd2d14ac0ef5e4bc0defccba4d47e6abc6"
    },
    {
        "name": "慢冷 (Live版)",
        "artist": "张碧晨 / 希林娜依高",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2043126974&auth=8d3076785257aa989956f85e47d64e6bfee68663",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168575643881&auth=894f470a075cb4c9439a30f1820a39906305f398",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2043126974&auth=46f6f2713c4381ddc4f4f2c835d5d163418611f0"
    },
    {
        "name": "落泪",
        "artist": "康熙 / TOYOKI",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2021434589&auth=85b49ac73e05cc4095114666192bbec5949961c9",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168306901774&auth=9811bc9f77c3adfdebb2d51f7f189e1c794cd4da",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2021434589&auth=8dcf51cfc30bf94a132c91ac03b70558f6ba6b4c"
    },
    {
        "name": "倒数",
        "artist": "G.E.M.邓紫棋",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1299550532&auth=e58c2d5a1d777d028f46b5efe558b2317a8bff9b",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163523944497&auth=6573dc7921779e789132772007063d8da6945adf",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1299550532&auth=42e8dd7409f32762863e3a7a08b45c3ff2d95bad"
    },
    {
        "name": "Bones",
        "artist": "Imagine Dragons",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1927389937&auth=e0ac44443559d1c19d5fdbe031e68c2445871a9f",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167137953001&auth=12d8f91fc8e5d536d7a744a5b6d683cf02ff1e77",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1927389937&auth=120220fdc88cbb2b064a26f041fc679be9e97177"
    },
    {
        "name": "删了吧",
        "artist": "烟(许佳豪)",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1891469546&auth=eb92b15c0208b106a0d020f1a27c398977f823cd",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166578333625&auth=48ca10f2430c3b6ec79ca475bf606a4e880ff0be",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1891469546&auth=792eb34554b458dc33f7cb4d504104c3ce99ef4c"
    },
    {
        "name": "大眠 (完整版)",
        "artist": "小乐哥（王唯乐）",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1413142894&auth=609f00a04d6410e68965bfe828ffff02aa087e27",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164605092552&auth=fc69863468c69dc47d430d9a81ffdf1cca234dee",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1413142894&auth=62d460047cffb2e962cd9e32346369730cc05e76"
    },
    {
        "name": "五月天",
        "artist": "火鸡",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2038163355&auth=a52877f18d902a545f457ac628d5763e393168e0",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168567531887&auth=e54fb7d288d62afc80e0611cd8ff09a760e201fe",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2038163355&auth=2d69ea6c95a2fc913600e3f138bfc5c146329d66"
    },
    {
        "name": "永不失联的爱",
        "artist": "周兴哲",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=523250334&auth=6d2dfcf242bcd3bb9bbf0bbce97b686a137f8752",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167105501079&auth=ed268bfb753fa079f3bb8c1d5441969f8bc4aa03",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=523250334&auth=1f089ea351d818eb936bd5ca4d5efe3fddf5e3f1"
    },
    {
        "name": "五百二十赫兹",
        "artist": "Capper",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1948572170&auth=1a6b549559c61a6d61a2254b62c79a1cdf1f828e",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167437121908&auth=df591b8a5c9b4cf3cd56192ccdc1bf097d9c8165",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1948572170&auth=4f55c35caf3af2a858e49dc1c4c186fce9c8903e"
    },
    {
        "name": "紫荆花盛开",
        "artist": "李荣浩 / 梁咏琪",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1959528822&auth=ae8a77f97c048aa6add4183749dad5fdd248f9a0",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167605022957&auth=d3b08d52488df4edf143d2b771c98e851318477f",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1959528822&auth=7079b05227c81d6c35659cd4a14f601ef4e03180"
    },
    {
        "name": "Sunflower (Spider-Man: Into the Spider-Verse)",
        "artist": "Post Malone / Swae Lee",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1318733599&auth=94a4b0602b5d1c7aff302aa61ce903cac5103ee2",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163936068098&auth=4ddc0c8b2a2b8ce4cd2ae79ccf77c96bcc914359",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1318733599&auth=c04fbcdf93ba8aec9d08e2c5b93776e76044343e"
    },
    {
        "name": "有些",
        "artist": "颜人中",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1406649619&auth=5be6178d0ba9d1ce2277ec7b45deb245a8fbc730",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164517295956&auth=fe8d473e86510d39f72f634a1f3d0c7550f82077",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1406649619&auth=8d81b3c580ccafab2e7abb2c9bfa08872b0a0801"
    },
    {
        "name": "你要的全拿走 (Live版)",
        "artist": "于文文 / 吉克隽逸",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2045089372&auth=f95bbcfd996f124a6ce1707f24a6b61953c5a47d",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168593049191&auth=023ce1d9c514730a14b925a6fccc631d51cabc10",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2045089372&auth=86d1ed22de2519075060e786890cf35c5b28a12e"
    },
    {
        "name": "像鱼",
        "artist": "王贰浪",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1331819951&auth=f8910f58b9364a51af4ef789f6a2ff2c3d1d6761",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163720047382&auth=b5ea6e530b1cadb831c765ca7b81013a700263a0",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1331819951&auth=09e050cef44d1b9bb109ff5b17b20fff281f31e6"
    },
    {
        "name": "保留",
        "artist": "郭顶",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=442869203&auth=4edada77560b641f5b018e2b368b912500d5f410",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=2946691248081599&auth=4b24e9b36b10690069c3dae45d3f8534ab80ad4c",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=442869203&auth=b857d3afe3ea0c247b7cdc631ea3f386f8425b04"
    },
    {
        "name": "你走以后1.0",
        "artist": "王恩信Est / 二胖u（王訫）",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1363205817&auth=ff700f3787c4cb1de1d811f5e0a56b421401c2d5",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164049623941&auth=211606094f77f2d43b9acbc1e1cdd6b05f9fefe5",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1363205817&auth=f64f414e60f435c5bdcfba87bdc5e7950608120c"
    },
    {
        "name": "呓语",
        "artist": "毛不易",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1417862046&auth=a198bf34f17afe917c0e88e73a503bffb77e5f93",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164640697307&auth=f8e6b88ebd1f7e7f805b7af41058c5e97b50acf9",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1417862046&auth=2a561b4135ebcb35f4d61a5eb6af3c9457237b47"
    },
    {
        "name": "浪漫主义",
        "artist": "姜云升",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1887917182&auth=d7e7917fb071ddc1690f2aeb23342ccc8cc56c87",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166531420475&auth=344a1526f4203a0f6e0746626a52dc67e7c0588a",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1887917182&auth=cb9e2aef632579ac22f58fc40dc4da13f055a266"
    },
    {
        "name": "桃花诺",
        "artist": "G.E.M.邓紫棋",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=480579393&auth=4cf03fb06bb66eaf5a1103a111e64d95a318bd1a",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=19050138463061697&auth=97991a1c35a916e220b57ee1a9c383518d56e568",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=480579393&auth=3dd6ab8ea202d29088b7809cc32db349cd07746f"
    },
    {
        "name": "最佳损友",
        "artist": "陈奕迅",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=65800&auth=d13e5581291486e26ca102c62b7fb301392bd7a9",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166577890720&auth=ecd5309207c7a0e35870e115e066daf0a5358152",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=65800&auth=0cc44afa3df3dc6fcfb34f550884f10e404ca9b7"
    },
    {
        "name": "年少有为",
        "artist": "李荣浩",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1293886117&auth=ec08c4f3e06d25c6975966b2916321b89d26706f",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163606377163&auth=d7a0db84a5b2341b1edd5d68429f25b584b21ea6",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1293886117&auth=0036ba33a1600930036e8bd532a12058f8347ee0"
    },
    {
        "name": "簇拥烈日的花",
        "artist": "Morerare / 迟里乌布",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1896178370&auth=62c2c0a19f6369119548fb8d2c28daf01464855b",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166635988818&auth=67be86df019eb6018b7bbfcfc1de0fafde09b7b7",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1896178370&auth=01f70c427bdc3ed5348c8cf8168ab41c57b8af5e"
    },
    {
        "name": "乐园",
        "artist": "沧桑Cang333 / 虎皮蛋 / 曲甲",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2021379728&auth=9021ca3f1e3412b45f57c92c9f57538a493018d5",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168299426988&auth=20e687fa3504e7f37dcb11d3515c39bb52def0bd",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2021379728&auth=45317cc4d7a1fbaa888c5a9254a93412e84c6727"
    },
    {
        "name": "麻雀",
        "artist": "李荣浩",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1407551413&auth=3d545d53e08f445d40bc5aeb13e6ad48bd15431d",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165182029540&auth=bf394fd409b4c95ea49012984612cf1a2249c8af",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1407551413&auth=3ab9d461ef9b2623dd62f5fafcf357ace84f4616"
    },
    {
        "name": "失眠飞行",
        "artist": "接个吻，开一枪 / 沈以诚 / 薛黛霏",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1365898499&auth=101eac85cc578cafbc5db98feb18e070f99cfbe4",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164083996255&auth=416daaf356b863ebb05dfac634f9149d51cef576",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1365898499&auth=1be2f508af34166e208dbaad6ad9bc58a872bf48"
    },
    {
        "name": "山楂树之恋",
        "artist": "程佳佳",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1381755293&auth=6c58a0b3cee9c4bb3578af962353bb1fff885ac2",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164260611202&auth=05d98adc4bb3c6c0bb0b9ac6a0a25c7b19d91854",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1381755293&auth=306cfaddb5cb5b9080f9011d7d15be959ffb25b1"
    },
    {
        "name": "Running Up That Hill (a deal with god)",
        "artist": "Barton",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1957926942&auth=263e51bba45711794b4ede4b6eddeb0c2780a865",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167694548771&auth=811bd38eb7fd98885c212983c39168ab9259f797",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1957926942&auth=0f1f71faae6489c9ce3c4c538137c041b4645991"
    },
    {
        "name": "失语者",
        "artist": "蔡健雅",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=36024442&auth=47d426abff11109245de333c5bce99db706ee205",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166118861127&auth=87aa19caa51d39fe4cdd4897643d2c140e6f7c41",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=36024442&auth=eac51c6edc0f073ead29b6a9c1e9712a40d71fb9"
    },
    {
        "name": "命运",
        "artist": "粉太狼",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1942041775&auth=7e7e95bcc8a7ffdc8d5eaa3b8afb7b3b966cdc24",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167350673553&auth=d5bba8a7bcd4e86e548073add699481f5f2afa70",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1942041775&auth=bb7365bff78cc5356cf919e26ee362f80c76d8d6"
    },
    {
        "name": "The Best Of Me",
        "artist": "Dion Timmer / The Arcturians",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1329938686&auth=fd2e1c0b4c7b903eedb9dce4b0984f70296d8d61",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951163705416566&auth=e0892495c4961229af4822227eb91b4a628a54df",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1329938686&auth=bc28f88613e1b5d4cb2545991556d0acdfcb6079"
    },
    {
        "name": "隆里电丝 (Live)",
        "artist": "盛宇D-SHINE / KEY.L刘聪 / ICE杨长青",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1964443044&auth=eb80bcbd9cdfb8751733bf63aec343bb6b168143",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167678761254&auth=1f0dc40fb685c9084be7e89e5014160c256f8930",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1964443044&auth=1055f5ce6fcb9cb0d23426aba0cc06656dd1bdaa"
    },
    {
        "name": "Once Upon a Time",
        "artist": "Max Oazo / Moonessa",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1299570939&auth=ab7b7bb0831f28735923ba4adee1b2f4aca44106",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167480965715&auth=1428f04b97534ffa55c01ce452771bb476f7255e",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1299570939&auth=b0ba1ce7837db750752efe47517b327db242984c"
    },
    {
        "name": "小半",
        "artist": "陈粒",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=421423806&auth=a8493b88caed5d72be09c0ccddd387b040c07d2a",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=1371091013186741&auth=fb20a5a223cb92a2d5634decb2731be4b13ead52",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=421423806&auth=9233136b61cd8a2dba711f1936c63294ba667940"
    },
    {
        "name": "Die For You",
        "artist": "The Weeknd",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=442867526&auth=4adc627062ad69be4a43ed9644840ab12628eff7",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167103667631&auth=62a791bbbe66bea4d04b9bed34ae80b06e4e53f2",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=442867526&auth=b0a0cba5abdd3bfbb168dadd3b9165ac8d9d2c65"
    },
    {
        "name": "I Wish My Mind Would Shut Up",
        "artist": "Ivoris",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1940074698&auth=94e6a540b306d50324d142f1a39e19724214c4b0",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168231895517&auth=9880a6e80a6a0bc8a7c73b94111f19264a811b3c",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1940074698&auth=cc8a2147f5eba8b4eb4d5b404e5fb538fba2d3ca"
    },
    {
        "name": "岁月神偷",
        "artist": "金玟岐",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=28285910&auth=ca51f282e798125bc349d0bbc14b81b577d423eb",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=18815942487303143&auth=40a52c7c4b22df36ba216982e923125034b5ca94",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=28285910&auth=29be7208eaf3a5bcd3fbd0c2b219c3b93846fa41"
    },
    {
        "name": "说唱入门教学2.0 (LIVE版)",
        "artist": "Wiz_H张子豪",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=2048371124&auth=4a16f482db2ebbe35f59239fa638a5c2deb8e820",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168620779856&auth=b0e8ef269afede83e0e6122c0bc3128e5df5134c",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=2048371124&auth=4a3c0a029ca5a4be4998c0f12f2840ed04a14e82"
    },
    {
        "name": "海底",
        "artist": "一支榴莲",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1430583016&auth=c5426e827ba88f88e5291c8916bf1e50ece2be59",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164799337803&auth=301e64e803d3ed0bd5d35640a93493bbe8e7cbb6",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1430583016&auth=e7cc473576d90de0546dd5c1ee9b96035c2d6724"
    },
    {
        "name": "我都明白",
        "artist": "范倪Liu",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1809100933&auth=901ce7373a83d25cd8cb115e81b1a23878881095",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165603993988&auth=e2ea36218b539d29cdd0a0f11d7da136ed73c137",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1809100933&auth=08afbc903f8562acc713a15d6aa1a9f9541a6a8e"
    },
    {
        "name": "Starboy",
        "artist": "The Weeknd / Daft Punk",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=431610014&auth=7cd8ffa562b710768417b6d1d5fd104c5e92e252",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167103667631&auth=62a791bbbe66bea4d04b9bed34ae80b06e4e53f2",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=431610014&auth=808cc22efa02cd25241efd7e54518786a5b0395e"
    },
    {
        "name": "浪漫血液",
        "artist": "林俊杰",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=29850683&auth=990440eddf4e8e35052d5496e36410914f9e8f9a",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166919095160&auth=fa1f9110ed3a1991433e620718e163131a2f1160",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=29850683&auth=8900f0f51b0941ae25364374a3ae47b178c8dbaa"
    },
    {
        "name": "步步",
        "artist": "五月天",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=28181103&auth=4c2c9d3535cf00cc125270c419d20377c3b10fb5",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168144493672&auth=9a3c6b708c590974f498de3eb478926204c05d49",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=28181103&auth=967e37a12fdd3fd19326a3e5396a92431d46d993"
    },
    {
        "name": "后来的我们",
        "artist": "五月天",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=422104138&auth=54e11d92b4746392f877dccb02cfd87f7fc2539e",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=3434874331529456&auth=e40bc9013038e752f420bc858a71a937d4cf63ad",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=422104138&auth=7fbc630353d02d4ca095096794ed3a31089732d7"
    },
    {
        "name": "I'll Do It",
        "artist": "Heidi Montag",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1340006512&auth=39c014e5194e8aca1a10321d175808fc5f9705ff",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951168590575280&auth=8f5abcf83af39846e4f43b7d064a0a474960fe50",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1340006512&auth=db91e6ddc303abf7f471a6a5721ce1efc5912979"
    },
    {
        "name": "我的名字",
        "artist": "焦迈奇",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=554241732&auth=f8f5c4f38a3b4587c60ecbe23257c552e9854af4",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951166267072680&auth=ef154a8d2304b12c552d90ecde719ac17b61a3d5",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=554241732&auth=0490f05e340d0f9301927143b4a36277116971e0"
    },
    {
        "name": "Cruel Summer",
        "artist": "Taylor Swift",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1382576173&auth=f5f2bd5fe2585bff998ffb873f9312831768ed58",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164260234943&auth=ba41c367304160e78e1eaed53a8ffe4663f2fd88",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1382576173&auth=af91d4065e626248eb627e7c5632f5288739928c"
    },
    {
        "name": "断线",
        "artist": "Shang / lil sophy",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=496370620&auth=0eb8cc01575d90168eb10274fce46a6199569061",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951162995598984&auth=d2a593e1923e85b062ba5fcd13378910007233e2",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=496370620&auth=e1901cc22ae78a3c132d8d334b782f7064272fbf"
    },
    {
        "name": "泡沫",
        "artist": "Swang多雷",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=518682659&auth=df23dc553349199e5a94c151daad3a25f078ac88",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951164764975405&auth=28523ee28d7d3915843d95bedf69e67c3eb7b473",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=518682659&auth=3a6630b4edc010a3341bbb7ad053c4c6c8fc5f48"
    },
    {
        "name": "过",
        "artist": "王嘉尔 / 林俊杰",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1804879213&auth=eb72c68e52df16c4fb5bb22af9ccd43f0841c6fc",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951165545588869&auth=f3e441772b42d0ad774508878e9976ca90a04677",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1804879213&auth=64eda68b4d18f850804bd9ceb6fa398fc18ba0aa"
    },
    {
        "name": "热恋情节",
        "artist": "吴子健REmi / kiya",
        "audio": "https://api.i-meto.com/meting/api?server=netease&type=url&id=1973046704&auth=a323cbb93e3f790d626f50abc20e0401f5fee90e",
        "cover": "https://api.i-meto.com/meting/api?server=netease&type=pic&id=109951167899063910&auth=2eba744cf42e99c2230e0b3cb27d85d0b1ae6a34",
        "lrc": "https://api.i-meto.com/meting/api?server=netease&type=lrc&id=1973046704&auth=5bd18d5df4e4f1131ebd61ef07653c4d62308739"
    }  
   
];