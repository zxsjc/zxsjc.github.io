var windowWidth = $(window).width();
var meting_api = 'https://api.mizore.cn/meting/api.php?server=:server&type=:type&id=:id';
console.log('\n' + ' %c kaygb-v3 by kaygb ' + ' %c https://blog.170601.xyz/archives/25.html ' + '\n' + '\n', 'color: #fff; background: #fd79a8; padding:5px 0;', 'background: #FFF; padding:5px 0;');
console.log("新版KZHomePage已经准备就绪，欢迎使用体验：https://github.com/kaygb/KZHomePage ")